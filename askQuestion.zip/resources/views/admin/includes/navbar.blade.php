<div class="navbar">
    <div class="navbar-inner">
        <div class="sidebar-pusher">
            <a href="javascript:void(0);" class="waves-effect waves-button waves-classic push-sidebar">
                <i class="fa fa-bars"></i>
            </a>
        </div>
        <div class="logo-box">
            <a href="/admin-dashboard" class="logo-text"><span>Modern</span></a>
        </div><!-- Logo Box -->

        <div class="topmenu-outer">
            <div class="top-menu">
                <ul class="nav navbar-nav navbar-left">
                    <li>
                        <a href="javascript:void(0);" class="waves-effect waves-button waves-classic sidebar-toggle"><i
                                class="fa fa-bars"></i></a>
                    </li>

                    <li>
                        <a href="javascript:void(0);"
                            class="waves-effect waves-button waves-classic toggle-fullscreen"><i
                                class="fa fa-expand"></i></a>
                    </li>

                </ul>
                <ul class="nav navbar-nav navbar-right">

                    <li>
                        <a href="/" class="log-out waves-effect waves-button waves-classic">
                            <span><i class="fa fa-sign-out m-r-xs"></i>Visit Website</span>
                        </a>
                    </li>
                </ul><!-- Nav -->
            </div><!-- Top Menu -->
        </div>
    </div>
</div><!-- Navbar -->
