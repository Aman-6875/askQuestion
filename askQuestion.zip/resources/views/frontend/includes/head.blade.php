
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/slick/slick.css">
    <link rel="stylesheet" href="/assets/slick/slick-theme.css">
    <!-- icon css-->
    <link rel="stylesheet" href="/assets/elagent-icon/style.css">
    <link rel="stylesheet" href="/assets/niceselectpicker/nice-select.css">
    <link rel="stylesheet" href="/assets/animation/animate.css">
    <link rel="stylesheet" href="/assets/mcustomscrollbar/jquery.mCustomScrollbar.min.css">
   
    <link rel="stylesheet" href="/css/style-main.css">
    <link rel="stylesheet" href="/css/responsive.css">
    <title>Ama - Social Questions and Answers HTML Template</title>
</head>